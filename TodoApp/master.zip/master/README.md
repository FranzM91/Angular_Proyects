### Sakai
# Install Node
> Nodejs 20
# Install Angular
> npm install -g @angular/cli@17

# nvm
> nvm i 20

# version NODE
> node -v

# version Angular
> ng version

## Paso 1
# instalar dependencias
> npm i

## paso 2
> ng s --o